To stop auto update run the DisableWindowsAutoUpdate file
after this check the image below to see what your interface should look like

To start auto update run the EnableWindowsAutoUpdate file